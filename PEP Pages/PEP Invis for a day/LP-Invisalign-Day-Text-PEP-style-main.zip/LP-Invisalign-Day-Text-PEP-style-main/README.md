# LP Invisalign Day Text (PEP style)
 
[screenshot](assets/images/preview.png)